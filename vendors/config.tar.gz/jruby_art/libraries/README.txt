Extract any vanilla processing libraries here, and they will be picked up by the library_loader unless you have set an alternative location in config.yml.
Suggested Libraries to include here:-
processing.org pdf url = https://processing.org/reference/libraries/pdf/index.html
processing.org sound url = https://processing.org/reference/libraries/sound/index.html
processing.org video url = https://processing.org/reference/libraries/video/index.html
Frederik Vanhoutte(http://www.wblut.com/) hemesh url=http://hemesh.wblut.com/

